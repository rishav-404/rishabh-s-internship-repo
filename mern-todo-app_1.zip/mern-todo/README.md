# MERN To-Do List App

A full-stack To-Do application built with **MongoDB Atlas + Express.js + React + Node.js**.

## Project Structure

```
mern-todo/
├── backend/
│   ├── server.js         ← Express API (POST /add, GET /tasks)
│   ├── package.json
│   └── .env.example      ← Copy this to .env and add your MongoDB URI
└── frontend/
    ├── src/
    │   ├── App.js        ← React UI (input + task list)
    │   ├── App.css       ← Styling
    │   └── index.js      ← React entry point
    ├── public/
    │   └── index.html
    └── package.json
```

## API Routes

| Method | Route        | Description           |
|--------|--------------|-----------------------|
| GET    | /tasks       | Fetch all tasks       |
| POST   | /add         | Add a new task        |
| PATCH  | /tasks/:id   | Toggle task complete  |
| DELETE | /tasks/:id   | Delete a task         |

## Setup & Run

### Step 1 — MongoDB Atlas Setup
1. Go to [mongodb.com/atlas](https://www.mongodb.com/atlas) and create a free account.
2. Create a free **M0 cluster**.
3. Under **Database Access**, create a user with a password.
4. Under **Network Access**, add IP `0.0.0.0/0` (allow all) for development.
5. Click **Connect → Drivers** and copy your connection string.

### Step 2 — Backend

```bash
cd backend

# Install dependencies
npm install

# Create your .env file
cp .env.example .env
# Edit .env and paste your MongoDB URI

# Start the server
npm start
# OR for auto-restart on changes:
npm run dev
```

Server runs at: `http://localhost:5000`

### Step 3 — Frontend

```bash
cd frontend

# Install dependencies
npm install

# Start React app
npm start
```

React app runs at: `http://localhost:3000`

> The `"proxy": "http://localhost:5000"` in frontend/package.json allows React to call
> the backend without CORS issues during development.

## How It Works

1. React renders an input field and **Add Task** button.
2. On click, React sends a **POST /add** request to Express with the task title.
3. Express validates the input, saves the task to **MongoDB Atlas**, and returns the saved task.
4. React immediately shows the new task in the list (no page reload needed).
5. On app load, React calls **GET /tasks** to fetch and display all saved tasks from MongoDB.
