// App.js — MERN To-Do List Frontend
import React, { useState, useEffect } from "react";
import "./App.css";

const API_URL = "http://localhost:5000";

function App() {
  const [tasks, setTasks] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [error, setError] = useState("");

  // ── Fetch all tasks from backend on component mount ──────────────────────
  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    setFetching(true);
    try {
      const response = await fetch(`${API_URL}/tasks`);
      const data = await response.json();
      setTasks(data);
    } catch (err) {
      setError("Could not connect to server. Make sure the backend is running.");
    } finally {
      setFetching(false);
    }
  };

  // ── POST /add — Send new task to backend ─────────────────────────────────
  const handleAddTask = async () => {
    if (inputValue.trim() === "") {
      setError("Please enter a task before adding.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/add`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: inputValue }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to add task");
      }

      const newTask = await response.json();
      setTasks([newTask, ...tasks]); // Add to top of list immediately
      setInputValue("");             // Clear input field
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // ── PATCH — Toggle task completion ───────────────────────────────────────
  const handleToggle = async (id) => {
    try {
      const response = await fetch(`${API_URL}/tasks/${id}`, {
        method: "PATCH",
      });
      const updatedTask = await response.json();
      setTasks(tasks.map((t) => (t._id === id ? updatedTask : t)));
    } catch (err) {
      setError("Failed to update task.");
    }
  };

  // ── DELETE — Remove a task ───────────────────────────────────────────────
  const handleDelete = async (id) => {
    try {
      await fetch(`${API_URL}/tasks/${id}`, { method: "DELETE" });
      setTasks(tasks.filter((t) => t._id !== id));
    } catch (err) {
      setError("Failed to delete task.");
    }
  };

  // ── Allow pressing Enter to add task ─────────────────────────────────────
  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleAddTask();
  };

  const completedCount = tasks.filter((t) => t.completed).length;

  return (
    <div className="app">
      {/* ── Header ── */}
      <header className="header">
        <div className="header-icon">✅</div>
        <h1 className="title">My Task List</h1>
        <p className="subtitle">MERN Stack — React + Express + MongoDB</p>
      </header>

      {/* ── Input Section ── */}
      <section className="input-section">
        <div className="input-row">
          <input
            type="text"
            className="task-input"
            placeholder="Enter a new task..."
            value={inputValue}
            onChange={(e) => {
              setInputValue(e.target.value);
              setError("");
            }}
            onKeyDown={handleKeyDown}
            disabled={loading}
          />
          <button
            className="add-btn"
            onClick={handleAddTask}
            disabled={loading}
          >
            {loading ? "Adding..." : "Add Task"}
          </button>
        </div>
        {error && <p className="error-msg">⚠️ {error}</p>}
      </section>

      {/* ── Stats Bar ── */}
      {tasks.length > 0 && (
        <div className="stats-bar">
          <span>{tasks.length} total</span>
          <span className="dot">·</span>
          <span className="completed-count">{completedCount} done</span>
          <span className="dot">·</span>
          <span>{tasks.length - completedCount} remaining</span>
        </div>
      )}

      {/* ── Task List ── */}
      <section className="task-list-section">
        {fetching ? (
          <div className="loading-state">
            <div className="spinner" />
            <p>Fetching tasks from MongoDB...</p>
          </div>
        ) : tasks.length === 0 ? (
          <div className="empty-state">
            <p className="empty-icon">📋</p>
            <p>No tasks yet. Add one above!</p>
          </div>
        ) : (
          <ul className="task-list">
            {tasks.map((task) => (
              <li key={task._id} className={`task-item ${task.completed ? "completed" : ""}`}>
                <button
                  className="check-btn"
                  onClick={() => handleToggle(task._id)}
                  title={task.completed ? "Mark incomplete" : "Mark complete"}
                >
                  {task.completed ? "✓" : "○"}
                </button>
                <span className="task-title">{task.title}</span>
                <span className="task-date">
                  {new Date(task.createdAt).toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "short",
                  })}
                </span>
                <button
                  className="delete-btn"
                  onClick={() => handleDelete(task._id)}
                  title="Delete task"
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* ── Footer ── */}
      <footer className="footer">
        <p>Data stored in <strong>MongoDB Atlas</strong> · API served by <strong>Express.js</strong></p>
      </footer>
    </div>
  );
}

export default App;
